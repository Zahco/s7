
#ifndef _YYSTYPE
#define _YYSTYPE
#define YYSTYPE double
#endif