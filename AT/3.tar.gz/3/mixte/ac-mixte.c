#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "mixte.h"

int main(void) {
  return EXIT_SUCCESS;
}
